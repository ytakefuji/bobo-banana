from collections import deque
from itertools import chain
from klotski import Klotski


def solve(puzzle):
    start_board = puzzle.start_board
    if puzzle.is_goal(start_board):
        print("Board is already solved")
        return [start_board]
    spaces = tuple(i for i, value in enumerate(start_board) if value == 0)
    to_visit = deque([])
    to_visit.append((puzzle.start_board, spaces))
    board_parents = {start_board: None}

    solution = None
    while to_visit and solution is None:
        board, spaces = to_visit.popleft()
        for new_board, new_spaces in puzzle.children(board, spaces):
            if new_board not in board_parents:
                board_parents[new_board] = board
                if puzzle.is_goal(new_board):
                    solution = new_board
                to_visit.append((new_board, new_spaces))

    solution_moves = [solution]
    last_board = solution
    while last_board != start_board:
        last_board = board_parents[last_board]
        solution_moves.append(last_board)

    solution_moves.reverse()
    return solution_moves


def print_solution(puzzle, solution, boards_per_line=5):
    " prints board states in solution "
    for move_number in range(0, len(solution), boards_per_line):
        puzzle.pretty_print(solution[move_number : move_number + boards_per_line])
        print(move_number)

    print("Length: ", len(solution) - 1)


def solve_demo():
    red_donkey = Klotski()
    solution = solve(red_donkey)
    print("Solved Red Donkey:")
    print_solution(red_donkey, solution)
if __name__ == "__main__":
    solve_demo()
